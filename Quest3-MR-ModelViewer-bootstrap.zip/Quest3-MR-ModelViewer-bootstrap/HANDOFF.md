# HANDOFF

## Goal
Produce a directly sideloadable Meta Quest 3 APK for a mixed-reality 3D model viewer using passthrough and Environment Depth.

## Safe current state
The repository is confirmed accessible with push/admin permissions. A bootstrap workflow has been prepared but the GitHub write tool disconnected before a commit was confirmed.

## Immediate next action
Retry GitHub access and commit:
- README.md
- .github/workflows/build-quest-apk.yml
- PROJECT_STATE.md
- AUDIT.md
- HANDOFF.md

Then inspect the first GitHub Actions run. If it fails, fix CI until an APK artifact is produced.

## Technical baseline
Meta OpenXR SDK tag: v85
Reference sample: Samples/XrSamples/XrPassthroughOcclusion
Environment depth extension: XR_META_environment_depth
Quest target: Quest 3 / Quest 3S

# PROJECT STATE

Version target: v0.1 hardware bring-up

Current architecture:
- Meta Quest 3 standalone
- Native Android + OpenXR
- Meta OpenXR SDK v85 reference sample
- Environment Depth extension: XR_META_environment_depth
- GitHub Actions APK build

Acceptance target:
- APK builds on GitHub runner
- installs on Quest 3
- launches into passthrough
- Environment Depth permission succeeds
- real environment can occlude virtual geometry

Next after acceptance:
- fork reference sample into project-owned native sources
- custom model viewer shell
- GLB/glTF import and manipulation

# Quest3 MR Model Viewer

Native Meta Quest 3 mixed-reality model viewer project.

## v0.1 hardware bring-up

The first milestone validates the platform layer before custom model importing is added:

- native Android / OpenXR on Quest 3
- color passthrough
- `XR_META_environment_depth`
- real-world depth occlusion
- ARM64 standalone APK
- cloud build through GitHub Actions

For this bring-up build, CI checks out Meta's official **Meta OpenXR SDK v85** and builds the `XrPassthroughOcclusion` sample. This gives us a known-good reference implementation for Environment Depth on Quest 3/3S while keeping this repository small.

## Downloading the APK

Open **Actions → Build Quest APK → latest successful run → Artifacts** and download `Quest3-MR-ModelViewer-v0.1`.

The artifact contains the debug APK and a SHA-256 checksum file.

## Roadmap

1. Reference Environment Depth bring-up
2. Own application shell
3. GLB/glTF loading
4. Controller/hand manipulation
5. True-size and preset scaling
6. Environment placement and occlusion
7. Spatial anchors
8. Measurement/inspection tools
